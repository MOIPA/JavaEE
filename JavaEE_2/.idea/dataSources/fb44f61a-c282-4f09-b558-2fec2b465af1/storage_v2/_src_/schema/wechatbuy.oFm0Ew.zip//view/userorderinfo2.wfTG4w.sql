create view userorderinfo2 as
  select
    `wechatbuy`.`theorder`.`promulgatorid` AS `promulgatorid`,
    `wechatbuy`.`theorder`.`orderid`       AS `orderid`,
    `wechatbuy`.`theorder`.`com`           AS `com`,
    `wechatbuy`.`theorder`.`ordercontent`  AS `ordercontent`,
    `wechatbuy`.`theorder`.`ordertheme`    AS `ordertheme`,
    `wechatbuy`.`theorder`.`ordertime`     AS `ordertime`,
    `wechatbuy`.`theorder`.`posttime`      AS `posttime`,
    `wechatbuy`.`orderpic`.`orderpicsrc`   AS `orderpicsrc`,
    `wechatbuy`.`account`.`account`        AS `account`,
    `wechatbuy`.`account`.`uiconsrc`       AS `uiconsrc`,
    `wechatbuy`.`userinfo`.`name`          AS `name`,
    `wechatbuy`.`userinfo`.`age`           AS `age`,
    `wechatbuy`.`userinfo`.`sex`           AS `sex`
  from (((`wechatbuy`.`theorder`
    join `wechatbuy`.`account`) join `wechatbuy`.`userinfo`) join `wechatbuy`.`orderpic`)
  where ((`wechatbuy`.`theorder`.`orderid` = `wechatbuy`.`orderpic`.`orderid`) and
         (`wechatbuy`.`theorder`.`promulgatorid` = `wechatbuy`.`account`.`aid`) and
         (`wechatbuy`.`account`.`aid` = `wechatbuy`.`userinfo`.`aid`));

