create view ruserorderinfo3 as
  select
    `main`.`orderid`       AS `orderid`,
    `main`.`account`       AS `account`,
    `main`.`ordertheme`    AS `ordertheme`,
    `main`.`ordercontent`  AS `ordercontent`,
    `main`.`ordertime`     AS `ordertime`,
    `main`.`promulgatorid` AS `promulgatorid`,
    `main`.`com`           AS `com`,
    `main`.`posttime`      AS `posttime`,
    `main`.`name`          AS `name`,
    `main`.`age`           AS `age`,
    `main`.`sex`           AS `sex`,
    `main`.`uiconsrc`      AS `uiconsrc`,
    (select `sub`.`orderpicsrc`
     from `wechatbuy`.`userorderinfo2` `sub`
     where (`sub`.`orderid` = `main`.`orderid`)
     order by rand()
     limit 0, 1)           AS `rorderpicsrc`
  from `wechatbuy`.`userorderinfo2` `main`
  group by `main`.`orderid`;

